from django.shortcuts import render

# Create your views here.
# def index(request):
#    return HttpResponse("Hello, world. You're at the betterfit index.")

def home(request):
    return render(request, 'home.html', {})

def generic(request):

    if request.method=="POST":
        print(request.POST)
        clothes_img=request.FILES["clothes_img"]
    return render(request, 'generic.html', {})

def elements(request):
    return render(request, 'elements.html', {})
